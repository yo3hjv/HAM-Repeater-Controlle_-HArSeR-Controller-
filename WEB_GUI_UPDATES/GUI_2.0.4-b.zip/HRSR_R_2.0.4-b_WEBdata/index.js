/**
 * ESP32 Repeater Controller - Index Page Functionality
 * Handles fetching and displaying repeater status information
 */

// Global variable to store the last valid RSSI value
let lastRssiValue = 0;

// Store repeater status information
let repeaterStatus = {
  repeaterState: 'Stand By',
  currentMode: 'Carrier',
  operationState: 'Stand By',
  totStatus: 'Normal',
  totTime: '',
  beaconStatus: 'Idle',
  rssiValue: '0 raw',
  rssiLthresh: 1400,  // Default low threshold
  rssiHthresh: 1800,  // Default high threshold
  carrierDetect: false,
  pttStatus: false,
  courtesyEnabled: true,
  tailToneEnabled: true,
  beaconMessage: '',
  beaconInterval: 0,
  beaconIntervalFormatted: '00:00',
  beaconEndMessageActive: '',
  beaconEndMessageLocked: '',
  beaconEndMessageActiveEnabled: false,
  beaconEndMessageLockedEnabled: false,
  calmDownTime: 0,
  useRssiMode: false
};

// WebSocket connection
let ws = null;
let wsConnected = false;
let wsReconnectInterval = null;

// Function to update RSSI threshold markers
function updateRssiThresholds() {
  console.log('Updating RSSI thresholds:', repeaterStatus.rssiLthresh, repeaterStatus.rssiHthresh);
  
  // Get the threshold elements
  const lowThreshold = document.getElementById('rssi-low-threshold');
  const highThreshold = document.getElementById('rssi-high-threshold');
  const lowLabel = document.getElementById('rssi-low-label');
  const highLabel = document.getElementById('rssi-high-label');
  const minLabel = document.getElementById('rssi-min-label');
  const maxLabel = document.getElementById('rssi-max-label');
  
  if (lowThreshold && highThreshold && lowLabel && highLabel) {
    // Define the RSSI range
    const minRssi = 0;
    const maxRssi = 4095;
    
    // Calculate percentages for positioning
    const lowPercentage = Math.min(100, Math.max(0, ((repeaterStatus.rssiLthresh - minRssi) / (maxRssi - minRssi)) * 100));
    const highPercentage = Math.min(100, Math.max(0, ((repeaterStatus.rssiHthresh - minRssi) / (maxRssi - minRssi)) * 100));
    
    // Position the threshold markers
    lowThreshold.style.left = lowPercentage + '%';
    highThreshold.style.left = highPercentage + '%';
    
    // Position and update the labels
    lowLabel.style.left = lowPercentage + '%';
    highLabel.style.left = highPercentage + '%';
    
    // Update the label text
    lowLabel.textContent = 'L: ' + repeaterStatus.rssiLthresh;
    highLabel.textContent = 'H: ' + repeaterStatus.rssiHthresh;
    
    // Update min/max labels
    if (minLabel) minLabel.textContent = minRssi;
    if (maxLabel) maxLabel.textContent = maxRssi;
  }
}

// Initialize when document is loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM loaded, initializing repeater status');
  
  // Initial update
  fetchRepeaterStatus();
  
  // Removed periodic AJAX polling as WebSocket updates are now used for real-time status
  
  // Initialize WebSocket listeners for real-time updates
  initWebSocketListeners();
  
  // Initial threshold update
  updateRssiThresholds();
});

// Function to update preferences via API (same pattern as settings.html)
function updateRepeaterPreferences(jsonData) {
  // Log the data being sent
  console.log('Sending data to API:', jsonData);
  
  // Send the data to the API endpoint
  fetch('/api/preferences/update', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(jsonData)
  })
  .then(response => response.json())
  .then(data => {
    console.log('API response:', data);
    // Refresh repeater status to show updated values
    fetchRepeaterStatus();
  })
  .catch(error => {
    console.error('Error updating preferences:', error);
  });
}

// Function to fetch repeater status from the server
function fetchRepeaterStatus() {
  const timestamp = new Date().toLocaleTimeString();
  console.log(`[${timestamp}] Fetching repeater status...`);
  
  // Add cache-busting parameter to prevent caching
  fetch('/api/repeater-status?_=' + Date.now())
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to fetch repeater status');
      }
      return response.json();
    })
    .then(data => {
      console.log('Received repeater status:', data);
      
      // Store the data
      repeaterStatus = data;
      
      // Now fetch preferences to get additional data
      return fetch('/api/preferences?_=' + Date.now());
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to fetch preferences');
      }
      return response.json();
    })
    .then(preferences => {
      console.log('Received preferences:', preferences);
      
      // Update repeaterStatus with additional data
      repeaterStatus.courtesyEnabled = preferences.CourtesyEnable === true || preferences.CourtesyEnable === 'true';
      // Ensure we're using the correct variable name and properly converting to boolean
      console.log('TailToneEnable value:', preferences.TailToneEnable, typeof preferences.TailToneEnable);
      repeaterStatus.tailToneEnabled = preferences.TailToneEnable === true || preferences.TailToneEnable === 'true';
      
      // Make sure userLockActive is properly updated from preferences
      console.log('userLockActive value:', preferences.userLockActive, typeof preferences.userLockActive);
      repeaterStatus.userLockActive = preferences.userLockActive === true || preferences.userLockActive === 'true';
      
      // Create combined beacon message based on repeater state
      const callsign = preferences.Callsign || '';
      let endMessage = '';
      
      // Determine which end message to use based on user lock state
      if (repeaterStatus.userLockActive) {
        // For locked state, use BeaconEndMessageLocked if enabled
        console.log('Locked state, BeaconEndMessageLocked:', preferences.BeaconEndMessageLocked);
        endMessage = preferences.BeaconEndMessageLocked || '';
      } else {
        // For active state, use BeaconEndMessageActive if enabled
        console.log('Active state, BeaconEndMessageActive:', preferences.BeaconEndMessageActive);
        endMessage = preferences.BeaconEndMessageActive || '';
      }
      
      // Combine callsign and end message
      repeaterStatus.beaconMessage = callsign + (endMessage ? ' ' + endMessage : '');
      
      // Format beacon interval as MMM:ss (minutes:seconds)
      const beaconInterval = parseInt(preferences.BeacInterval) || 0;
      const minutes = Math.floor(beaconInterval);
      const seconds = Math.round((beaconInterval - minutes) * 60);
      repeaterStatus.beaconIntervalFormatted = `${minutes}:${seconds.toString().padStart(2, '0')}`;
      
      // Update the status elements
      updateRepeaterStatus();
    })
    .catch(error => {
      console.error('Error fetching repeater status:', error);
      // Just log the error, don't use simulated data
      // The UI will continue to show the last known good state
    });
}

// Update repeater status elements
function updateRepeaterStatus() {
  console.log('Updating repeater status UI with:', repeaterStatus);
  
  // Maintain the RSSI bar during status updates using the last known value
  updateRssiBar();
  
  // Update main repeater state text
  const repeaterStateText = document.getElementById('repeater-state');
  if (repeaterStateText) {
    repeaterStateText.textContent = repeaterStatus.repeaterState;
    console.log('Updated repeater state text to:', repeaterStatus.repeaterState);
  } else {
    console.error('Could not find repeater-state element');
  }
  
  // Update repeater state indicator
  const repeaterStateIndicator = document.getElementById('repeater-state-indicator');
  if (repeaterStateIndicator) {
    // Remove all status classes
    repeaterStateIndicator.classList.remove('status-active', 'status-standby', 'status-error', 'status-beacon', 'status-inactive');
    
    // Add appropriate class based on state
    if (repeaterStatus.repeaterState === 'Repeating') {
      repeaterStateIndicator.classList.add('status-active');
    } else if (repeaterStatus.repeaterState === 'Locked') {
      repeaterStateIndicator.classList.add('status-error');
    } else if (repeaterStatus.repeaterState === 'Active') {
      repeaterStateIndicator.classList.add('status-beacon');
    } else {
      repeaterStateIndicator.classList.add('status-standby');
    }
  } else {
    console.error('Could not find repeater-state-indicator element');
  }
  
  // Update RSSI value
  const rssiValueElement = document.getElementById('rssi-value');
  if (rssiValueElement) {
    rssiValueElement.textContent = repeaterStatus.rssiValue;
    
    // Update the RSSI meter bar
    const rssiValue = parseInt(repeaterStatus.rssiValue);
    if (!isNaN(rssiValue)) {
      // Get the RSSI bar element
      const rssiBar = document.getElementById('rssi-bar');
      if (rssiBar) {
        // Update the RSSI bar width based on value (assuming 0-4095 range for ESP32 ADC)
        const percentage = Math.min(100, Math.max(0, (rssiValue / 4095) * 100));
        rssiBar.style.width = percentage + '%';
        
        // Change color based on signal strength
        if (percentage > 70) {
          rssiBar.style.backgroundColor = '#4CAF50'; // Green for strong signal
        } else if (percentage > 30) {
          rssiBar.style.backgroundColor = '#FFC107'; // Yellow for medium signal
        } else {
          rssiBar.style.backgroundColor = '#F44336'; // Red for weak signal
        }
      }
    }
  }
  
  // Update carrier detect status
  const carrierStatusElement = document.getElementById('carrier-status');
  const carrierIndicator = document.getElementById('carrier-indicator');
  if (carrierStatusElement && carrierIndicator) {
    // Update text
    carrierStatusElement.textContent = repeaterStatus.carrierDetect ? 'Active' : 'Inactive';
    carrierStatusElement.className = repeaterStatus.carrierDetect ? 'lang-active' : 'lang-inactive';
    
    // Update indicator
    carrierIndicator.classList.remove('status-active', 'status-inactive');
    carrierIndicator.classList.add(repeaterStatus.carrierDetect ? 'status-active' : 'status-inactive');
  }
  
  // Update PTT status
  const pttStatusElement = document.getElementById('ptt-status');
  const pttIndicator = document.getElementById('ptt-indicator');
  if (pttStatusElement && pttIndicator) {
    // Update text
    pttStatusElement.textContent = repeaterStatus.pttStatus ? 'Active' : 'Inactive';
    pttStatusElement.className = repeaterStatus.pttStatus ? 'lang-active' : 'lang-inactive';
    
    // Update indicator
    pttIndicator.classList.remove('status-active', 'status-inactive');
    pttIndicator.classList.add(repeaterStatus.pttStatus ? 'status-active' : 'status-inactive');
  }
  
  // Update current mode
  const currentModeElement = document.getElementById('current-mode');
  if (currentModeElement) {
    currentModeElement.textContent = repeaterStatus.useRssiMode ? "RSSI" : "Logic Carrier";
  }
  
  // Update operation state
  const operationStateText = document.getElementById('operation-state-text');
  if (operationStateText) {
    operationStateText.textContent = repeaterStatus.operationState;
  }
  
  // Update operation state indicator
  const operationStateIndicator = document.getElementById('operation-state-indicator');
  if (operationStateIndicator) {
    // Remove all status classes
    operationStateIndicator.classList.remove('status-active', 'status-standby', 'status-error', 'status-beacon', 'status-inactive');
    
    // Add appropriate class based on state
    if (repeaterStatus.operationState === 'Repeating') {
      operationStateIndicator.classList.add('status-active');
    } else if (repeaterStatus.operationState === 'ToT Reached') {
      operationStateIndicator.classList.add('status-error');
    } else if (repeaterStatus.operationState === 'Sending Beacon') {
      operationStateIndicator.classList.add('status-beacon');
    } else {
      operationStateIndicator.classList.add('status-standby');
    }
  }
  
  // Update ToT status
  const totStatusText = document.getElementById('tot-status-text');
  if (totStatusText) {
    // Use translateText function if available, otherwise use the raw status
    if (typeof translateText === 'function') {
      totStatusText.textContent = translateText(repeaterStatus.totStatus.toLowerCase(), repeaterStatus.totStatus);
      // Update the class to match the current status for proper translation
      totStatusText.className = 'lang-' + repeaterStatus.totStatus.toLowerCase();
    } else {
      totStatusText.textContent = repeaterStatus.totStatus;
    }
  }
  
  // Update ToT indicator
  const totIndicator = document.getElementById('tot-indicator');
  if (totIndicator) {
    // Remove all status classes
    totIndicator.classList.remove('status-active', 'status-standby', 'status-error', 'status-beacon', 'status-inactive');
    
    // Add appropriate class based on ToT status
    if (repeaterStatus.totStatus === 'Reached') {
      totIndicator.classList.add('status-error');
    } else {
      totIndicator.classList.add('status-standby');
    }
  }
  
  // Update ToT time
  const totTimeElement = document.getElementById('tot-time');
  if (totTimeElement) {
    totTimeElement.textContent = repeaterStatus.toTime ? `${repeaterStatus.toTime} sec` : '';
  }
  
  // Update Calm-Down Timer
  const calmDownTimeElement = document.getElementById('calm-down-time');
  if (calmDownTimeElement) {
    calmDownTimeElement.textContent = repeaterStatus.calmDownTime ? `${repeaterStatus.calmDownTime} sec` : '';
  }
  
  // Update beacon status
  const beaconStatusText = document.getElementById('beacon-status-text');
  if (beaconStatusText) {
    beaconStatusText.textContent = repeaterStatus.beaconStatus;
  }
  
  // Update beacon indicator
  const beaconIndicator = document.getElementById('beacon-indicator');
  if (beaconIndicator) {
    // Remove all status classes
    beaconIndicator.classList.remove('status-active', 'status-standby', 'status-error', 'status-beacon', 'status-inactive');
    
    // Add appropriate class based on beacon status
    if (repeaterStatus.beaconStatus === 'Sending') {
      beaconIndicator.classList.add('status-beacon');
    } else {
      beaconIndicator.classList.add('status-inactive');
    }
  }
  
  // Update courtesy tone status
  const courtesyStateText = document.getElementById('courtesy-state-text');
  const courtesyIndicator = document.getElementById('courtesy-indicator');
  if (courtesyStateText && courtesyIndicator) {
    // Update text
    courtesyStateText.textContent = repeaterStatus.courtesyEnabled ? 'Enabled' : 'Disabled';
    
    // Update indicator
    courtesyIndicator.classList.remove('status-active', 'status-inactive');
    courtesyIndicator.classList.add(repeaterStatus.courtesyEnabled ? 'status-active' : 'status-inactive');
  }
  
  // Update tail tone status
  const tailStateText = document.getElementById('tail-state-text');
  const tailIndicator = document.getElementById('tail-indicator');
  if (tailStateText && tailIndicator) {
    // Log the current value for debugging
    console.log('Tail Tone Enabled:', repeaterStatus.tailToneEnabled, typeof repeaterStatus.tailToneEnabled);
    
    // Update text
    tailStateText.textContent = repeaterStatus.tailToneEnabled ? 'Enabled' : 'Disabled';
    
    // Update indicator
    tailIndicator.classList.remove('status-active', 'status-inactive');
    tailIndicator.classList.add(repeaterStatus.tailToneEnabled ? 'status-active' : 'status-inactive');
  }
  
  // Update beacon end message active
  const beaconEndMessageActiveElement = document.getElementById('beacon-end-message-active');
  const beaconEndMessageActiveStatusElement = document.getElementById('beacon-end-message-active-status');
  if (beaconEndMessageActiveElement) {
    beaconEndMessageActiveElement.textContent = repeaterStatus.beaconEndMessageActive || '';
  }
  if (beaconEndMessageActiveStatusElement) {
    console.log('Updating beacon end message active status with:', repeaterStatus.beaconEndMessageActiveEnabled);
    beaconEndMessageActiveStatusElement.textContent = repeaterStatus.beaconEndMessageActiveEnabled ? ' (Enabled)' : ' (Disabled)';
  }
  
  // Update beacon end message locked
  const beaconEndMessageLockedElement = document.getElementById('beacon-end-message-locked');
  const beaconEndMessageLockedStatusElement = document.getElementById('beacon-end-message-locked-status');
  if (beaconEndMessageLockedElement) {
    beaconEndMessageLockedElement.textContent = repeaterStatus.beaconEndMessageLocked || '';
  }
  if (beaconEndMessageLockedStatusElement) {
    console.log('Updating beacon end message locked status with:', repeaterStatus.beaconEndMessageLockedEnabled);
    beaconEndMessageLockedStatusElement.textContent = repeaterStatus.beaconEndMessageLockedEnabled ? ' (Enabled)' : ' (Disabled)';
  }
  
  // Update beacon interval
  const beaconIntervalElement = document.getElementById('beacon-interval');
  if (beaconIntervalElement) {
    beaconIntervalElement.textContent = repeaterStatus.beacInterval ? `${repeaterStatus.beacInterval} min` : '';
  }
  
  // WebSocket doesn't handle Beacon Interval updates - using Ajax instead
  
  // Repeater state is now handled by the handleStatusUpdate function
};



// Handler for status updates from WebSocket
const handleStatusUpdate = function(data) {
  console.log('Index: Handling status update:', data);
  
  // Update our local state with all available fields
  if (data.repeaterState !== undefined) {
    repeaterStatus.repeaterState = data.repeaterState;
  }
  
  if (data.carrier !== undefined) {
    repeaterStatus.carrierDetect = data.carrier === 'true' || data.carrier === true;
  }
  
  if (data.ptt !== undefined) {
    repeaterStatus.pttStatus = data.ptt === 'true' || data.ptt === true;
  }
  
  if (data.courtesyEnable !== undefined) {
    repeaterStatus.courtesyEnabled = data.courtesyEnable === 'true' || data.courtesyEnable === true || data.courtesyEnable === 1;
  }
  
  if (data.tailToneEnable !== undefined) {
    repeaterStatus.tailToneEnabled = data.tailToneEnable === 'true' || data.tailToneEnable === true || data.tailToneEnable === 1;
  }
  
  if (data.beaconMessage !== undefined) {
    repeaterStatus.beaconMessage = data.beaconMessage;
  }
  
  if (data.useRssiMode !== undefined) {
    repeaterStatus.useRssiMode = data.useRssiMode === 'true' || data.useRssiMode === true || data.useRssiMode === 1;
  }
  
  if (data.toTime !== undefined) {
    repeaterStatus.toTime = data.toTime;
  }
  
  if (data.beaconEndMessageActive !== undefined) {
    repeaterStatus.beaconEndMessageActive = data.beaconEndMessageActive;
  }
  
  if (data.beaconEndMessageActiveEnabled !== undefined) {
    console.log('Beacon End Message Active Enabled raw value:', data.beaconEndMessageActiveEnabled, 'type:', typeof data.beaconEndMessageActiveEnabled);
    repeaterStatus.beaconEndMessageActiveEnabled = data.beaconEndMessageActiveEnabled === 'true' || data.beaconEndMessageActiveEnabled === true || data.beaconEndMessageActiveEnabled === 1;
    console.log('Processed beaconEndMessageActiveEnabled:', repeaterStatus.beaconEndMessageActiveEnabled);
  }
  
  // Update RSSI threshold values if available
  if (data.rssiLthresh !== undefined) {
    repeaterStatus.rssiLthresh = parseInt(data.rssiLthresh);
    updateRssiThresholds();
  }
  
  if (data.rssiHthresh !== undefined) {
    repeaterStatus.rssiHthresh = parseInt(data.rssiHthresh);
    updateRssiThresholds();
  }
  
  if (data.beaconEndMessageLocked !== undefined) {
    repeaterStatus.beaconEndMessageLocked = data.beaconEndMessageLocked;
  }
  
  if (data.beaconEndMessageLockedEnabled !== undefined) {
    repeaterStatus.beaconEndMessageLockedEnabled = data.beaconEndMessageLockedEnabled === 'true' || data.beaconEndMessageLockedEnabled === true || data.beaconEndMessageLockedEnabled === 1;
  }
  
  if (data.BeacInterval !== undefined) {
    repeaterStatus.beacInterval = data.BeacInterval;
  }
  
  if (data.calmDownTime !== undefined) {
    repeaterStatus.calmDownTime = data.calmDownTime;
  }
  
  // Update the UI with the new data
  updateRepeaterStatus();
};

// Handler for RSSI updates from WebSocket
const handleRssiUpdate = function(data) {
  console.log('Index: Handling RSSI update:', data);
  
  if (data.value !== undefined) {
    // Parse and store the RSSI value in our global variable
    const rssiValue = parseInt(data.value);
    if (!isNaN(rssiValue)) {
      lastRssiValue = rssiValue;
      console.log('Stored lastRssiValue:', lastRssiValue);
    }
    
    // Update the RSSI value in our local state
    repeaterStatus.rssiValue = data.value + ' raw';
    
    // Update the RSSI display
    const rssiValueElement = document.getElementById('rssi-value');
    if (rssiValueElement) {
      rssiValueElement.textContent = repeaterStatus.rssiValue;
    }
    
    // Update the RSSI bar using our helper function
    updateRssiBar();
  }
};

// Function to update the RSSI bar using the last known RSSI value
function updateRssiBar() {
  const rssiBar = document.getElementById('rssi-bar');
  if (rssiBar) {
    // Use the same scaling as the threshold markers
    const minRssi = 0;
    const maxRssi = 4095;
    
    // Use the global lastRssiValue
    console.log('Updating RSSI bar with value:', lastRssiValue);
    
    // Calculate percentage using the same formula as thresholds
    const percentage = Math.min(100, Math.max(0, ((lastRssiValue - minRssi) / (maxRssi - minRssi)) * 100));
    rssiBar.style.width = percentage + '%';
    
    // Change color based on threshold values
    if (lastRssiValue >= repeaterStatus.rssiHthresh) {
      rssiBar.style.backgroundColor = '#4CAF50'; // Green for above high threshold
    } else if (lastRssiValue >= repeaterStatus.rssiLthresh) {
      rssiBar.style.backgroundColor = '#FFC107'; // Yellow for between thresholds
    } else {
      rssiBar.style.backgroundColor = '#F44336'; // Red for below low threshold
    }
  }
};

// Function to initialize WebSocket listeners
function initWebSocketListeners() {
  console.log('Index: Starting WebSocket listener initialization');
  
  // Wait for the global WebSocket object to be available
  const checkInterval = setInterval(function() {
    console.log('Index: Checking for global WebSocket object...');
    
    if (window.repeaterWS && typeof window.repeaterWS.addListener === 'function') {
      clearInterval(checkInterval);
      console.log('Index: WebSocket global object found, setting up listeners');
      
      // Set up backward compatibility
      ws = window.repeaterWS.connection;
      wsConnected = window.repeaterWS.connected;
      wsReconnectInterval = window.repeaterWS.reconnectInterval;
      
      // Add listeners for different message types
      window.repeaterWS.addListener('rssi', handleRssiUpdate);
      window.repeaterWS.addListener('status', handleStatusUpdate);
      
      // Add connection status listener
      window.repeaterWS.addListener('connection', function(data) {
        console.log('Index: WebSocket connection status changed:', data.status);
        wsConnected = data.status === 'connected';
      });
      
      // Add error listener
      window.repeaterWS.addListener('error', function(data) {
        console.error('Index: WebSocket error:', data.error);
      });
      
      console.log('Index: WebSocket listeners set up successfully');
    } else {
      console.log('Index: Global WebSocket object not available yet, waiting...');
    }
  }, 500); // Check every 500ms
}
